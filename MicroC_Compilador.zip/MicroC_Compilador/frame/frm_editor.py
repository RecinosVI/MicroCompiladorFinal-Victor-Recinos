import tkinter as tk
from tkinter import ttk
from tkinter import filedialog
from tkinter import messagebox
import os

from compilador.analizador_lexico import AnalizadorLexico


# =====================================
# CLASE FRAME
# =====================================
class Frame:

    def __init__(
        self,
        root
    ):

        self.root = root

        self.root.title(
            "MicroC Compilador - Fase I y II"
        )

        self.root.geometry(
            "1200x700"
        )

        self.root.configure(
            bg="#1E1E1E"
        )

        self.Archivo = ""

        self.Analizador = (
            AnalizadorLexico()
        )

        self.CrearInterfaz()

    # =================================
    # INTERFAZ
    # =================================
    def CrearInterfaz(self):

        estilo = ttk.Style()

        estilo.theme_use("clam")

        # ==========================
        # TABLA
        # ==========================
        estilo.configure(

            "Treeview",

            background="#1E1E1E",

            foreground="white",

            fieldbackground="#1E1E1E",

            rowheight=30,

            borderwidth=0,

            font=(
                "Segoe UI",
                10
            )
        )

        estilo.map(

            "Treeview",

            background=[
                (
                    "selected",
                    "#007ACC"
                )
            ]
        )


        estilo.configure(

            "Treeview.Heading",

            background="#2D2D30",

            foreground="white",

            relief="flat",

            font=(
                "Segoe UI",
                10,
                "bold"
            )
        )

        estilo.map(

            "Treeview.Heading",

            background=[
                (
                    "active",
                    "#2D2D30"
                )
            ]
        )

        barra = tk.Frame(
            self.root,
            bg="#2D2D30",
            height=50
        )

        barra.pack(
            fill="x"
        )

        estilo_btn = {

            "bg": "#3C3C3C",
            "fg": "white",
            "font": (
                "Segoe UI",
                10,
                "bold"
            ),
            "relief": "flat",
            "cursor": "hand2",
            "padx": 15,
            "pady": 8
        }

        tk.Button(
            barra,
            text="Nuevo",
            command=self.OpcNuevo_Click,
            **estilo_btn
        ).pack(
            side="left",
            padx=5,
            pady=5
        )

        tk.Button(
            barra,
            text="Abrir",
            command=self.OpcAbrir_Click,
            **estilo_btn
        ).pack(
            side="left",
            padx=5
        )

        tk.Button(
            barra,
            text="Guardar",
            command=self.OpcGuardar_Click,
            **estilo_btn
        ).pack(
            side="left",
            padx=5
        )

        tk.Button(
            barra,
            text="Guardar Como",
            command=self.OpcGuardarComo_Click,
            **estilo_btn
        ).pack(
            side="left",
            padx=5
        )

        tk.Button(
            barra,
            text="Compilar",
            bg="#0E639C",
            fg="white",
            font=(
                "Segoe UI",
                10,
                "bold"
            ),
            relief="flat",
            command=self.OpcCompilar_Click
        ).pack(
            side="left",
            padx=5
        )

        tk.Button(
            barra,
            text="Salir",
            bg="#C42B1C",
            fg="white",
            relief="flat",
            command=self.OpcSalir_Click
        ).pack(
            side="right",
            padx=10
        )

        panel = tk.PanedWindow(
            self.root,
            sashrelief="flat",
            bg="#1E1E1E"
        )

        panel.pack(
            fill="both",
            expand=True
        )


        frame_codigo = tk.Frame(
            panel,
            bg="#1E1E1E"
        )

        lbl_codigo = tk.Label(
            frame_codigo,
            text="Código Fuente",
            bg="#1E1E1E",
            fg="white",
            font=(
                "Segoe UI",
                12,
                "bold"
            )
        )

        lbl_codigo.pack(
            anchor="w",
            padx=10,
            pady=5
        )

        self.TextCodigo = tk.Text(

            frame_codigo,

            bg="#1E1E1E",

            fg="#DCDCDC",

            insertbackground="white",

            selectbackground="#264F78",

            font=(
                "Consolas",
                12
            ),

            undo=True,

            wrap="none",

            bd=0
        )

        scroll_codigo = tk.Scrollbar(
            frame_codigo,
            command=self.TextCodigo.yview
        )

        scroll_horizontal = tk.Scrollbar(
            frame_codigo,
            orient="horizontal",
            command=self.TextCodigo.xview
        )

        self.TextCodigo.config(
            xscrollcommand=
            scroll_horizontal.set
        )

        scroll_horizontal.pack(
            side="bottom",
            fill="x"
        )

        self.TextCodigo.config(
            yscrollcommand=
            scroll_codigo.set
        )

        scroll_codigo.pack(
            side="right",
            fill="y"
        )

        self.TextCodigo.pack(
            fill="both",
            expand=True,
            padx=10,
            pady=5
        )

        panel.add(
            frame_codigo
        )

        frame_tokens = tk.Frame(
            panel,
            bg="#1E1E1E"
        )

        lbl_tokens = tk.Label(
            frame_tokens,
            text="Lista de Tokens",
            bg="#1E1E1E",
            fg="white",
            font=(
                "Segoe UI",
                12,
                "bold"
            )
        )

        lbl_tokens.pack(
            anchor="w",
            padx=10,
            pady=5
        )

        columnas = (
            "Linea",
            "Lexema",
            "Token",
            "Tipo"
        )

        self.Tabla = ttk.Treeview(
            frame_tokens,
            columns=columnas,
            show="headings"
        )

        self.Tabla.heading(
            "Linea",
            text="Línea"
        )

        self.Tabla.heading(
            "Lexema",
            text="Lexema"
        )

        self.Tabla.heading(
            "Token",
            text="Token"
        )

        self.Tabla.heading(
            "Tipo",
            text="Tipo"
        )

        self.Tabla.column(
            "Linea",
            width=70,
            anchor="center"
        )

        self.Tabla.column(
            "Lexema",
            width=220,
            anchor="w"
        )

        self.Tabla.column(
            "Token",
            width=100,
            anchor="center"
        )

        self.Tabla.column(
            "Tipo",
            width=180,
            anchor="center"
)

        scroll_vertical = ttk.Scrollbar(
            frame_tokens,
            orient="vertical",
            command=self.Tabla.yview
        )

        self.Tabla.configure(
            yscrollcommand=
            scroll_vertical.set
        )

        scroll_vertical.pack(
            side="right",
            fill="y"
        )

        self.Tabla.pack(
            fill="both",
            expand=True,
            padx=10,
            pady=5
        )

        panel.add(
            frame_tokens
        )


        frame_status = tk.Frame(
            self.root,
            bg="#252526",
            height=30
        )

        frame_status.pack(
            fill="x"
        )

        self.lblEstado = tk.Label(

            frame_status,

            text="Listo",

            bg="#252526",

            fg="white",

            anchor="w",

            font=(
                "Segoe UI",
                10
            ),

            padx=10
        )

        self.lblEstado.pack(
            side="left"
        )

        self.lblContador = tk.Label(

            frame_status,

            text="Tokens: 0",

            bg="#252526",

            fg="#4EC9B0",

            font=(
                "Segoe UI",
                10,
                "bold"
            )
        )

        self.lblContador.pack(
            side="right",
            padx=20
        )

    def OpcNuevo_Click(
        self
    ):

        self.TextCodigo.delete(
            "1.0",
            tk.END
        )

        self.Archivo = ""

        self.lblEstado.config(
            text="Nuevo archivo"
        )

    def OpcAbrir_Click(
        self
    ):

        ruta = (
            filedialog
            .askopenfilename(

                filetypes=[

                    (
                        "Archivos C/C++",
                        "*.cpp *.c *.txt"
                    )
                ]
            )
        )

        if ruta:

            self.Archivo = ruta

            with open(

                ruta,
                "r",
                encoding="utf-8"

            ) as archivo:

                contenido = (
                    archivo.read()
                )

            self.TextCodigo.delete(
                "1.0",
                tk.END
            )

            self.TextCodigo.insert(
                tk.END,
                contenido
            )

            self.lblEstado.config(
                text="Archivo abierto"
            )

    def OpcGuardar_Click(
        self
    ):

        if self.Archivo == "":

            self.OpcGuardarComo_Click()

            return

        contenido = (
            self.TextCodigo.get(
                "1.0",
                tk.END
            )
        )

        with open(

            self.Archivo,
            "w",
            encoding="utf-8"

        ) as archivo:

            archivo.write(
                contenido
            )

        self.lblEstado.config(
            text="Archivo guardado"
        )

    def OpcGuardarComo_Click(
        self
    ):

        ruta = (
            filedialog
            .asksaveasfilename(

                defaultextension=
                ".cpp"
            )
        )

        if ruta:

            self.Archivo = ruta

            self.OpcGuardar_Click()


    def OpcSalir_Click(
        self
    ):

        self.root.quit()

    def OpcCompilar_Click(
        self
    ):

        for item in (
            self.Tabla
            .get_children()
        ):

            self.Tabla.delete(
                item
            )

        contenido = (
            self.TextCodigo.get(
                "1.0",
                tk.END
            )
        )

        archivo_temp = (
            "codigo_temp.cpp"
        )

        with open(

            archivo_temp,
            "w",
            encoding="utf-8"

        ) as archivo:

            archivo.write(
                contenido
            )

        ListaTokens = (

            self.Analizador
            .AnalisisLexico(
                archivo_temp
            )
        )

        for token in ListaTokens:

            self.Tabla.insert(

                "",

                tk.END,

                values=(

                    token[
                        "linea"
                    ],

                    token[
                        "lexema"
                    ],

                    token[
                        "token"
                    ],

                    token[
                        "tipo"
                    ]
                )
            )

        errores = 0

        for token in ListaTokens:

            if (
                token["tipo"]
                ==
                "ERROR_LEXICO"
            ):

                errores += 1

        self.lblEstado.config(

            text=(

                f"Compilación finalizada | "
                f"Errores léxicos: {errores}"
            )
        )

        self.lblContador.config(

            text=(

                f"Tokens: "
                f"{len(ListaTokens)}"
            )
        )
