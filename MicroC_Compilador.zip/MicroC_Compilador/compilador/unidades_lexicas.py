# =====================================
# CLASE UNIDADES LEXICAS
# =====================================
class UnidadesLexicas:

    def __init__(self):

        # ==========================
        # PALABRAS RESERVADAS
        # ==========================
        self.palabras_reservadas = {

            "int": 101,
            "float": 102,
            "double": 103,
            "char": 104,
            "void": 105,
            "if": 106,
            "else": 107,
            "while": 108,
            "for": 109,
            "return": 110,
            "main": 111,
            "break": 112,
            "continue": 113,
            "switch": 114,
            "case": 115,
            "default": 116,
            "do": 117,
            "const": 118
        }

        # ==========================
        # SIMBOLOS
        # ==========================
        self.simbolos = {

            "+": 201,
            "-": 202,
            "*": 203,
            "/": 204,

            "=": 205,
            "==": 206,
            "!=": 207,

            "<": 208,
            ">": 209,
            "<=": 210,
            ">=": 211,

            ";": 212,
            ",": 213,

            "{": 214,
            "}": 215,

            "(": 216,
            ")": 217,

            "[": 218,
            "]": 219
        }

        # ==========================
        # TOKENS GENERALES
        # ==========================
        self.TOKEN_IDENTIFICADOR = 300
        self.TOKEN_ENTERO = 301
        self.TOKEN_REAL = 302
        self.TOKEN_COMENTARIO = 303
        self.TOKEN_ERROR = 999

    # =================================
    # GetTokenPalabra(String Lexema)
    # =================================
    def GetTokenPalabra(
        self,
        lexema
    ):

        if lexema in self.palabras_reservadas:

            return self.palabras_reservadas[
                lexema
            ]

        return self.TOKEN_IDENTIFICADOR

    # =================================
    # GetTokenSimbolo(String Lexema)
    # =================================
    def GetTokenSimbolo(
        self,
        lexema
    ):

        if lexema in self.simbolos:

            return self.simbolos[
                lexema
            ]

        return self.TOKEN_ERROR