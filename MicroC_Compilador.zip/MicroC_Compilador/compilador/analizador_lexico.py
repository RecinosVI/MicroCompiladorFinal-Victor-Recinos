from compilador.unidades_lexicas import (
    UnidadesLexicas
)


# =====================================
# CLASE ANALIZADOR LEXICO
# =====================================
class AnalizadorLexico:

    def __init__(self):

        self.Unidades = (
            UnidadesLexicas()
        )

    # =================================
    # Int GetAlfabetoAlfanumerico(char c)
    # =================================
    def GetAlfabetoAlfanumerico(
        self,
        c
    ):

        return (
            c.isalpha()
            or c == "_"
        )

    # =================================
    # Int GetAlfabetoNumero(char c)
    # =================================
    def GetAlfabetoNumero(
        self,
        c
    ):

        return c.isdigit()

    # =================================
    # Int GetAlfabetoSimbolo(char c)
    # =================================
    def GetAlfabetoSimbolo(
        self,
        c
    ):

        simbolos = (
            "+-*/=<>!;,{}()[]"
        )

        return c in simbolos

    # =================================
    # Void IdentificadorPalabraReservada
    # =================================
    def IdentificadorPalabraReservada(
        self,
        lexema
    ):

        token = (
            self.Unidades
            .GetTokenPalabra(
                lexema
            )
        )

        if (
            token ==
            self.Unidades
            .TOKEN_IDENTIFICADOR
        ):

            tipo = (
                "IDENTIFICADOR"
            )

        else:

            tipo = (
                "PALABRA_RESERVADA"
            )

        return {

            "token": token,
            "tipo": tipo
        }

    # =================================
    # Void EnteroReal(String Archivo)
    # =================================
    def EnteroReal(
        self,
        lexema
    ):

        if "." in lexema:

            return {

                "token":
                self.Unidades
                .TOKEN_REAL,

                "tipo":
                "REAL"
            }

        return {

            "token":
            self.Unidades
            .TOKEN_ENTERO,

            "tipo":
            "ENTERO"
        }

    # =================================
    # Void AutomataComentario
    # =================================
    def AutomataComentario(
        self,
        linea,
        posicion
    ):

        if (
            posicion + 1
            >= len(linea)
        ):

            return None

        doble = (
            linea[posicion]
            +
            linea[
                posicion + 1
            ]
        )

        # Comentario simple //
        if doble == "//":

            comentario = (
                linea[
                    posicion:
                ].strip()
            )

            return {

                "lexema":
                comentario,

                "tipo":
                "COMENTARIO",

                "token":
                self.Unidades
                .TOKEN_COMENTARIO,

                "avance":
                len(linea)
            }

        return None

    # =================================
    # List<String> AnalisisLexico
    # =================================
    def AnalisisLexico(
        self,
        archivo
    ):

        ListaTokens = []

        with open(
            archivo,
            "r",
            encoding="utf-8"
        ) as archivo_fuente:

            lineas = (
                archivo_fuente
                .readlines()
            )

        numero_linea = 1

        for linea in lineas:

            # Limpiar tabs
            linea = (
                linea
                .replace(
                    "\t",
                    " "
                )
                .replace(
                    "\r",
                    ""
                )
            )

            posicion = 0

            while (
                posicion
                < len(linea)
            ):

                caracter = (
                    linea[
                        posicion
                    ]
                )

                # ==================
                # ESPACIOS
                # ==================
                if (
                    caracter
                    .isspace()
                ):

                    posicion += 1
                    continue

                # ==================
                # COMENTARIOS
                # ==================
                comentario = (
                    self
                    .AutomataComentario(
                        linea,
                        posicion
                    )
                )

                if comentario:

                    ListaTokens.append({

                        "linea":
                        numero_linea,

                        "lexema":
                        comentario[
                            "lexema"
                        ],

                        "token":
                        comentario[
                            "token"
                        ],

                        "tipo":
                        comentario[
                            "tipo"
                        ]
                    })

                    break

                # ==================
                # PALABRAS
                # ==================
                if (
                    self
                    .GetAlfabetoAlfanumerico(
                        caracter
                    )
                ):

                    lexema = ""

                    while (

                        posicion
                        < len(linea)

                        and

                        (
                            linea[
                                posicion
                            ]
                            .isalnum()

                            or

                            linea[
                                posicion
                            ]
                            == "_"
                        )
                    ):

                        lexema += (
                            linea[
                                posicion
                            ]
                        )

                        posicion += 1

                    resultado = (
                        self
                        .IdentificadorPalabraReservada(
                            lexema
                        )
                    )

                    ListaTokens.append({

                        "linea":
                        numero_linea,

                        "lexema":
                        lexema,

                        "token":
                        resultado[
                            "token"
                        ],

                        "tipo":
                        resultado[
                            "tipo"
                        ]
                    })

                    continue

                # ==================
                # NUMEROS
                # ==================
                if (
                    self
                    .GetAlfabetoNumero(
                        caracter
                    )
                ):

                    lexema = ""
                    punto = False

                    while (
                        posicion
                        < len(linea)
                    ):

                        actual = (
                            linea[
                                posicion
                            ]
                        )

                        if (
                            actual
                            .isdigit()
                        ):

                            lexema += actual

                        elif (
                            actual
                            == "."
                            and
                            not punto
                        ):

                            punto = True
                            lexema += actual

                        else:
                            break

                        posicion += 1

                    resultado = (
                        self
                        .EnteroReal(
                            lexema
                        )
                    )

                    ListaTokens.append({

                        "linea":
                        numero_linea,

                        "lexema":
                        lexema,

                        "token":
                        resultado[
                            "token"
                        ],

                        "tipo":
                        resultado[
                            "tipo"
                        ]
                    })

                    continue

                # ==================
                # SIMBOLOS
                # ==================
                if (
                    self
                    .GetAlfabetoSimbolo(
                        caracter
                    )
                ):

                    doble = ""

                    if (
                        posicion + 1
                        < len(linea)
                    ):

                        doble = (

                            caracter

                            +

                            linea[
                                posicion + 1
                            ]
                        )

                    token = (
                        self.Unidades
                        .GetTokenSimbolo(
                            doble
                        )
                    )

                    if (
                        token !=
                        self.Unidades
                        .TOKEN_ERROR
                    ):

                        ListaTokens.append({

                            "linea":
                            numero_linea,

                            "lexema":
                            doble,

                            "token":
                            token,

                            "tipo":
                            "SIMBOLO"
                        })

                        posicion += 2
                        continue

                    token = (
                        self.Unidades
                        .GetTokenSimbolo(
                            caracter
                        )
                    )

                    ListaTokens.append({

                        "linea":
                        numero_linea,

                        "lexema":
                        caracter,

                        "token":
                        token,

                        "tipo":
                        "SIMBOLO"
                    })

                    posicion += 1
                    continue

                # ==================
                # ERROR LEXICO
                # ==================
                ListaTokens.append({

                    "linea":
                    numero_linea,

                    "lexema":
                    caracter,

                    "token":
                    self.Unidades
                    .TOKEN_ERROR,

                    "tipo":
                    "ERROR_LEXICO"
                })

                posicion += 1

            numero_linea += 1

        return ListaTokens