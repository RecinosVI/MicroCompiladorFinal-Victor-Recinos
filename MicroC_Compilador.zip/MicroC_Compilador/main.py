import tkinter as tk

from frame.frm_editor import Frame


def main():

    root = tk.Tk()

    app = Frame(root)

    root.mainloop()


if __name__ == "__main__":
    main()