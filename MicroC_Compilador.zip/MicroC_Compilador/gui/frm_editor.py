﻿import tkinter as tk
from tkinter import ttk
from tkinter import filedialog
from tkinter import messagebox
import os

from compilador.analizador_lexico import AnalizadorLexico


class Frame:

    def __init__(self, root):
        self.root = root
        self.root.title("MicroC Compilador - Fase I y II")
        self.root.geometry("1200x700")
        self.root.configure(bg="#1E1E1E")
        self.Archivo = ""
        self.Analizador = AnalizadorLexico()
        self.CrearInterfaz()

    def CrearInterfaz(self):
        estilo = ttk.Style()
        estilo.theme_use("clam")
        estilo.configure("Treeview", background="#252526", foreground="white", rowheight=28, fieldbackground="#252526")
        estilo.configure("Treeview.Heading", background="#333333", foreground="white", font=("Segoe UI", 10, "bold"))

        barra = tk.Frame(self.root, bg="#2D2D30", height=50)
        barra.pack(fill="x")

        estilo_btn = {"bg": "#3C3C3C", "fg": "white", "font": ("Segoe UI", 10, "bold"), "relief": "flat", "cursor": "hand2", "padx": 15, "pady": 8}

        tk.Button(barra, text="Nuevo", command=self.OpcNuevo_Click, **estilo_btn).pack(side="left", padx=5, pady=5)
        tk.Button(barra, text="Abrir", command=self.OpcAbrir_Click, **estilo_btn).pack(side="left", padx=5)
        tk.Button(barra, text="Guardar", command=self.OpcGuardar_Click, **estilo_btn).pack(side="left", padx=5)
        tk.Button(barra, text="Guardar Como", command=self.OpcGuardarComo_Click, **estilo_btn).pack(side="left", padx=5)
        tk.Button(barra, text="Compilar", bg="#0E639C", fg="white", font=("Segoe UI", 10, "bold"), relief="flat", command=self.OpcCompilar_Click).pack(side="left", padx=5)
        tk.Button(barra, text="Salir", bg="#C42B1C", fg="white", relief="flat", command=self.OpcSalir_Click).pack(side="right", padx=10)

        panel = tk.PanedWindow(self.root, sashrelief="flat", bg="#1E1E1E")
        panel.pack(fill="both", expand=True)

        frame_codigo = tk.Frame(panel, bg="#1E1E1E")
        tk.Label(frame_codigo, text="Codigo Fuente", bg="#1E1E1E", fg="white", font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=10, pady=5)
        self.TextCodigo = tk.Text(frame_codigo, bg="#1E1E1E", fg="white", insertbackground="white", font=("Consolas", 12), undo=True)
        scroll_codigo = tk.Scrollbar(frame_codigo, command=self.TextCodigo.yview)
        self.TextCodigo.config(yscrollcommand=scroll_codigo.set)
        scroll_codigo.pack(side="right", fill="y")
        self.TextCodigo.pack(fill="both", expand=True, padx=10, pady=5)
        panel.add(frame_codigo)

        frame_tokens = tk.Frame(panel, bg="#1E1E1E")
        tk.Label(frame_tokens, text="Lista de Tokens", bg="#1E1E1E", fg="white", font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=10, pady=5)
        columnas = ("Linea", "Lexema", "Token")
        self.Tabla = ttk.Treeview(frame_tokens, columns=columnas, show="headings")
        self.Tabla.heading("Linea", text="Linea")
        self.Tabla.heading("Lexema", text="Lexema")
        self.Tabla.heading("Token", text="Token")
        self.Tabla.column("Linea", width=80)
        self.Tabla.column("Lexema", width=180)
        self.Tabla.column("Token", width=100)
        scroll_tabla = ttk.Scrollbar(frame_tokens, orient="vertical", command=self.Tabla.yview)
        self.Tabla.configure(yscrollcommand=scroll_tabla.set)
        scroll_tabla.pack(side="right", fill="y")
        self.Tabla.pack(fill="both", expand=True, padx=10, pady=5)
        panel.add(frame_tokens)

        self.lblEstado = tk.Label(self.root, text="Listo", bg="#007ACC", fg="white", anchor="w", padx=10)
        self.lblEstado.pack(fill="x")

    def OpcNuevo_Click(self):
        self.TextCodigo.delete("1.0", tk.END)
        self.Archivo = ""
        self.lblEstado.config(text="Nuevo archivo")

    def OpcAbrir_Click(self):
        ruta = filedialog.askopenfilename(filetypes=[("Archivos C/C++", "*.cpp *.c *.txt")])
        if ruta:
            self.Archivo = ruta
            with open(ruta, "r", encoding="utf-8") as archivo:
                contenido = archivo.read()
            self.TextCodigo.delete("1.0", tk.END)
            self.TextCodigo.insert(tk.END, contenido)
            self.lblEstado.config(text="Archivo abierto")

    def OpcGuardar_Click(self):
        if self.Archivo == "":
            self.OpcGuardarComo_Click()
            return
        contenido = self.TextCodigo.get("1.0", tk.END)
        with open(self.Archivo, "w", encoding="utf-8") as archivo:
            archivo.write(contenido)
        self.lblEstado.config(text="Archivo guardado")

    def OpcGuardarComo_Click(self):
        ruta = filedialog.asksaveasfilename(defaultextension=".cpp")
        if ruta:
            self.Archivo = ruta
            self.OpcGuardar_Click()

    def OpcSalir_Click(self):
        self.root.quit()

    def OpcCompilar_Click(self):
        for item in self.Tabla.get_children():
            self.Tabla.delete(item)
        contenido = self.TextCodigo.get("1.0", tk.END)
        archivo_temp = "codigo_temp.cpp"
        with open(archivo_temp, "w", encoding="utf-8") as archivo:
            archivo.write(contenido)
        ListaTokens = self.Analizador.AnalisisLexico(archivo_temp)
        for token in ListaTokens:
            self.Tabla.insert("", tk.END, values=(token["linea"], token["lexema"], token["token"]))
        self.lblEstado.config(text=f"Compilacion finalizada - {len(ListaTokens)} tokens")
